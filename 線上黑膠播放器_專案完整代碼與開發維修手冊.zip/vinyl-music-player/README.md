# 🎵 線上黑膠音樂播放器與桌面應用程式 (Vinyl Music Player v2.0)

<div align="center">

![Vinyl Music Player](public/favicon.svg)

**一個以擬真黑膠唱片機為核心美學的跨平台音樂播放器與桌面應用程式**  
*極致純淨聽感儀式感 • 雙引擎音訊核心 • 全功能離線 PWA • 桌面懸浮小寵物 • 智慧回饋管理*

[![React 19](https://img.shields.io/badge/React-19.0-61dafb?logo=react&logoColor=white)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.7-3178c6?logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Vite](https://img.shields.io/badge/Vite-8.3-646cff?logo=vite&logoColor=white)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-3.4-38bdf8?logo=tailwindcss&logoColor=white)](https://tailwindcss.com/)
[![Tauri v2](https://img.shields.io/badge/Tauri-2.0-24c8db?logo=tauri&logoColor=white)](https://tauri.app/)
[![License: MIT](https://img.shields.io/badge/License-MIT-amber.svg)](LICENSE)
[![Zero Ads](https://img.shields.io/badge/Ads-0%25%20Zero%20Ads-emerald.svg)](#)

[🌐 線上開源倉庫](https://github.com/eines0903/Vinyl-Music-Player) • [📦 一鍵下載最新專案包](https://github.com/eines0903/Vinyl-Music-Player/archive/refs/heads/main.zip) • [📖 操作手冊目錄](#-專案文件分類與導覽地圖)

</div>

---

## 👥 主創團隊 (Core Authors & Creators)

> **Designed & Built by 温采穎 & 蔡懷萱**  
> 本專案秉持「**極致擬真美學、純淨無廣告、隱私優先、自主可控**」的開發理念，完全開放原始碼供全球聽友與開發者學習、協作與共創。

| 主創成員 | 核心角色與貢獻範疇 |
| :--- | :--- |
| **温采穎** | **共同主創 (Co-Creator)** / 產品概念設計、全域介面排版、動態歌詞與黑膠物理視覺架構 |
| **蔡懷萱** | **共同主創 (Co-Creator)** / 多媒體音訊雙引擎、桌面原生整合、IndexedDB 離線存儲與回饋系統架構 |

---

## 📁 專案文件分類與導覽地圖 (Documentation)

為方便使用者、協作者與開發維護團隊查閱，專案所有技術與操作文檔已依層級系統化分類存放於 [`docs/`](docs/) 目錄與專案根目錄中：

```text
vinyl-music-player/
├── README.md                              # 🌟 專案旗艦首頁與功能技術全覽 (即本手冊)
├── docs/                                  # 📚 系統化分類文件庫
│   ├── 01_使用者操作手冊.md               # 📘 使用者操作手冊 (全功能上手、PWA離線安裝、快捷鍵)
│   ├── 02_開發維修改正手冊.md             # 🛠️ 完整開發與維修手冊 (14大歷史重大修訂、踩坑與代碼比對)
│   └── 03_架構與模組設計指南.md           # 🏗️ 系統架構圖、Hook狀態流、資料庫綱要與API整合指南
├── USER_MANUAL.md                         # 📘 根目錄使用者操作手冊 (英文命名標準檔)
├── PROJECT_DEVELOPMENT_MANUAL.md          # 🛠️ 根目錄開發維修手冊 (英文命名標準檔)
├── 黑膠播放器_使用者操作手冊.md             # 📘 繁體中文對應操作手冊 (方便本機直接開啟)
└── 黑膠播放器_完整開發維修改正手冊.md       # 🛠️ 繁體中文對應開發手冊 (方便本機直接開啟)
```

### 📖 文件速查指引：
1. **如果您是一般聽歌使用者**：請閱讀 [`docs/01_使用者操作手冊.md`](docs/01_使用者操作手冊.md)，內含 MP3 匯入、歌詞自動搜尋、桌面迷你播放器拖曳與 PWA 離線安裝步驟。
2. **如果您是協作者或二次開發者**：請查閱 [`docs/02_開發維修改正手冊.md`](docs/02_開發維修改正手冊.md)，內含 14 項重大 Bug 排解細節（如切歌防中斷、唯一 ID 匹配、雙軌儲存等）。
3. **如果您想深入探究系統內部架構**：請查閱 [`docs/03_架構與模組設計指南.md`](docs/03_架構與模組設計指南.md)，內含 Mermaid 架構圖、IndexedDB v4 Schema 與 Hooks 呼叫鏈。

---

## ✨ 核心功能特色全覽 (Core Features)

### 1. 💿 擬真黑膠唱片機與物理唱針動畫
* **唱針擺入與歸位**：點擊播放時，金屬質感唱針平滑擺入黑膠凹槽；暫停或切換時優雅抬起歸位。
* **黑膠旋轉紋理**：採用 CSS 3D 渲染精緻同心圓凹槽光澤反光，播放時 33⅓ RPM 等速旋轉，中央顯示專輯高解析封面。

### 2. 🔀 雙引擎混合播放核心 (Dual Audio Engine)
* **本機高音質 MP3 引擎**：原生支援拖曳多首音訊檔，極速解析並以 Blob 形式儲存於本機。
* **YouTube MV 串流嵌入引擎**：支援貼入任何 YouTube MV / 音樂網址，自動正規化萃取影片 ID，並無縫融入主佇列播放。
* **防切歌中斷機制 (Play Interruption Protection)**：徹底解決瀏覽器頻繁切歌時出現的 `AbortError`，確保音訊平滑切換。

### 3. 🐾 桌面寵物懸浮迷你黑膠 (Draggable Mini Player)
* 尺寸僅 280px 的超可愛桌面懸浮卡片，滑鼠按住即可**隨意拖曳至螢幕任意角落**。
* 具備完整縮圖黑膠旋轉、歌曲進度條、上一首/播放/下一首、**獨立音量滑動拉桿**、一鍵靜音與循環模式控制。

### 4. 📴 全功能離線播放 (Offline PWA & IndexedDB v4)
* 內建 **Service Worker** 與 Web App Manifest，點擊頂部 **「📱 安裝 App」** 即可將網頁直接安裝成電腦或手機桌面獨立應用程式。
* **雙軌持久儲存**：歌曲二進位音檔、專輯封面、動態歌詞與清單完全存入本機 IndexedDB v4 與 LocalStorage 備份，**即使拔掉網路線、重開機也依然能流暢播放本機歌曲**！

### 5. 📜 動態滾動 LRC 歌詞與全球開放線上檢索 (LRCLIB)
* 毫秒級動態 LRC 歌詞解析，伴隨旋律即時置中高亮滾動，支援純文字歌詞自動優雅降級。
* 整合 **LRCLIB 全球開放歌詞庫**，輸入歌曲名稱即可一鍵自動線上檢索並同步動態歌詞。

### 6. 🎨 Apple Music 高解析封面檢索與 ID3 標籤解析
* 整合 **Apple Music / iTunes Search API**，輸入歌名自動檢索並替換官方 1000x1000 高解析度正方形專輯封面。
* 內建二進位 ID3v2 標籤解析器，MP3 拖曳匯入時自動讀取內嵌封面與作者名稱。

### 7. 📑 多清單自訂管理與個人專屬聆聽報告 (Monthly Wrapped)
* 自由建立、重新命名與刪除多組個人播放清單（例如：「深夜沉浸」、「工作專注」）。
* 系統自動計算每首曲目的累積播放次數，自動生成「**最近一個月最愛歌曲 (Monthly Favorites)**」。
* 一鍵生成專屬「**個人聆聽習慣報告**」，以視覺化圖表回顧總播放次數、最愛歌曲 Top 5 與常聽歌手排行。

### 8. ✏️ 播放器名稱一鍵自訂重新命名 (Player Renaming)
* 點擊頂部播放器名稱旁的鉛筆圖示，即可直接輸入自訂名稱（如個人專屬、情侶聯名或品牌標題）。
* 支援 Enter 儲存、Esc 取消，修改後自動即時同步瀏覽器分頁標題與桌面迷你播放器視窗標籤！

### 9. ⚙️ 按鍵排列、形狀、配色主題與全域快捷鍵個人化 (Button Settings)
* **按鍵自訂排序與隱藏**：可隨心調換頂部各功能按鈕順序，不常用的按鈕亦可一鍵隱藏。
* **3 款按鍵外觀**：💊 圓角膠囊、🔲 圓潤卡片、⏹️ 俐落方角。
* **4 款按鍵配色**：🌈 經典繽紛、🖤 極簡黑透、🌟 復古琥珀金、⚡ 霓虹電光。
* **全域快捷鍵自訂**：預設空白鍵播放/暫停、左右方向鍵切歌、M 鍵開關迷你黑膠，支援按下任意鍵即時錄製重新綁定。

### 10. 💬 專業用戶回饋與每月試算表系統 (Feedback & Excel Export)
* **一般用戶回饋填寫**：支援功能建議、問題回報、歌曲歌詞等多維度分類，可評 1~5 顆星（⭐）。
* **回饋送出確認憑證卡片**：送出後即時顯示時間、內容與環境重點，絕不閃退。
* **🔐 站長隱私管理員後台**：預設密碼 `0903`，可自行修改密碼。一般訪客無法看見任何歷史回饋。
* **📊 自適應欄位寬度表格 (Auto-layout Table)**：進入後台後，各欄位尺寸依內容多寡自動彈性調整，內容自動折行展開，清爽舒適。
* **🔍 裝置環境「重點精煉顯示」**：將冗長 User-Agent 字串精萃為 `💻 Windows 10/11 · Chrome (電腦)` 等簡明標籤，hover 仍可查看完整代碼。
* **📑 一鍵匯出 UTF-8 BOM CSV / Excel 試算表**：可按月份篩選，檔案雙擊以 Microsoft Excel 或 Google Sheets 開啟繁體中文 **100% 絕無亂碼**。
* **🌐 Google 試算表跨設備同步 (Webhook)**：支援填入 Google Apps Script 網址，當全球任何使用者提交回饋時，自動即時轉存至您的 Google 雲端試算表。

---

## 🗂️ 專案目錄結構與模組職責 (Directory Structure)

```text
vinyl-music-player/
├── docs/                             # 系統化文件庫
│   ├── 01_使用者操作手冊.md          # 使用者完整操作指南
│   ├── 02_開發維修改正手冊.md        # 14 大核心維修改正與架構歷史紀錄
│   └── 03_架構與模組設計指南.md      # Mermaid 架構圖、資料庫綱要與 API 客戶端
├── public/                           # 靜態資源與離線 PWA 核心
│   ├── favicon.svg                   # 向量黑膠唱機網站圖標
│   ├── icons.svg                     # 常用圖標集
│   ├── manifest.json                 # PWA 應用程式安裝清單
│   └── sw.js                         # Service Worker 離線快取控制腳本
├── scripts/                          # 自動化腳本
│   └── test-runner.mjs               # 自動化測試套件 (模組、API與邏輯驗證)
├── src/                              # 核心原始程式碼
│   ├── assets/                       # 圖片與靜態資源
│   ├── components/                   # UI 元件層
│   │   ├── BatchUploader.tsx         # 本機多首 MP3 批次拖曳解析器
│   │   ├── ButtonSettingsModal.tsx   # 按鍵排序、文字、外觀與快捷鍵個人化設定彈窗
│   │   ├── CoverModal.tsx            # 封面自訂與 Apple Music 自動檢索彈窗
│   │   ├── FeedbackModal.tsx         # 用戶回饋表單、自適應表格管理與試算表匯出彈窗
│   │   ├── ListeningReportModal.tsx  # 個人聆聽習慣統計與熱門總結彈窗
│   │   ├── LyricModal.tsx            # 歌詞手動編輯與 LRCLIB 線上自動檢索彈窗
│   │   ├── LyricViewer.tsx           # 置中毫秒級動態 LRC 歌詞檢視器
│   │   ├── MiniPlayer.tsx            # 280px 桌面懸浮迷你寵物黑膠播放器
│   │   ├── PlaylistDrawer.tsx        # 抽屜式播放清單管理 (支援 🔻/🔺 折疊與清單切換)
│   │   ├── SortModal.tsx             # 歌曲排序方式選單 (手動/歌名/日期/熱門)
│   │   ├── VinylRecord.tsx           # 擬真黑膠唱機與唱針物理動畫元件
│   │   └── YouTubeModal.tsx          # YouTube MV 網址正規化與嵌入彈窗
│   ├── constants/                    # 常數配置 (主題外觀配色等)
│   ├── hooks/                        # 核心業務邏輯 Hooks
│   │   ├── useAudioPlayer.ts         # 雙引擎播放器 (音量/靜音/循環模式/防切歌中斷)
│   │   ├── useButtonSettings.ts      # 按鍵個人化設定狀態管理與 LocalStorage 持久化
│   │   ├── useKeyboardShortcuts.ts   # 全域無衝突快捷鍵監聽器
│   │   └── usePlaylistManager.ts     # 清單切換/洗牌/排序/播放次數統計/不可變ID匹配
│   ├── types/                        # TypeScript 型別定義
│   │   ├── customButtons.ts          # 按鈕外觀、形狀、主題與快捷鍵型別
│   │   ├── feedback.ts               # FeedbackItem, FeedbackType 型別定義
│   │   └── song.ts                   # SongItem, Playlist, PlaybackMode 型別定義
│   └── utils/                        # 核心工具函式庫
│       ├── coverSearch.ts            # Apple Music 官方封面檢索與 YT 縮圖解析
│       ├── deviceInfo.ts             # 瀏覽器與裝置環境重點精煉解析模組
│       ├── feedbackExport.ts         # RFC 4180 CSV 試算表匯出模組 (支援 UTF-8 BOM 防中文亂碼)
│       ├── formatTime.ts             # 分秒時間格式化工具
│       ├── indexedDb.ts              # IndexedDB v4 本機永久資料庫 (歌曲/清單/回饋雙軌存儲)
│       ├── lyricParser.ts            # 正則毫秒級動態 LRC 歌詞解析器
│       ├── lyricSearch.ts            # LRCLIB 全球開放動態歌詞 API 連線工具
│       ├── metadataParser.ts         # jsmediatags 二進位 ID3 標籤解析器
│       └── shuffle.ts                # Fisher-Yates 嚴格真隨機洗牌演算法
├── src-tauri/                        # Tauri v2 原生桌面應用程式底層 (Rust)
├── index.html                        # 網頁入口與 PWA Service Worker 註冊
├── package.json                      # 依賴套件配置
├── tailwind.config.js                # Tailwind CSS 樣式與動畫配置
└── vite.config.ts                    # Vite 構建配置
```

---

## 📂 具體檔案職責與用途清單 (File-by-File Detailed Catalog)

### 1. 根目錄配置與文檔 (Root Files)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `README.md` | 專案旗艦首頁說明文件（功能總覽、技術架構、檔案清單、快捷鍵與主創署名） |
| `index.html` | 網頁應用主入口 HTML（掛載 React 根節點、中文字體載入與 PWA Service Worker 註冊） |
| `package.json` | 專案相依套件宣告與 npm 執行腳本配置（dev, build, tauri 等） |
| `package-lock.json` | 鎖定所有 npm 套件精確版本與相依性樹狀結構 |
| `vite.config.ts` | Vite 現代構建工具設定檔（React 外掛、開發伺服器端口與打包優化） |
| `tsconfig.json` | TypeScript 編譯器全域根設定檔 |
| `tsconfig.app.json` | 前端 React / TSX 應用程式編譯與型別檢查規則 |
| `tsconfig.node.json` | Vite 與 Node.js 構建工具環境之 TypeScript 規則配置 |
| `tailwind.config.js` | Tailwind CSS 樣式系統配置（自訂黑膠旋轉動畫、毛玻璃主題色調） |
| `postcss.config.js` | CSS 後處理器配置（自動補全前綴與 Tailwind 整合） |
| `.oxlintrc.json` | 靜態代碼檢查與代碼風格規範（Oxlint）設定 |
| `.gitignore` | Git 版本控制忽略清單（排除 node_modules、dist 等） |
| `USER_MANUAL.md` | 使用者端完整操作手冊（標準英文檔名） |
| `PROJECT_DEVELOPMENT_MANUAL.md` | 完整開發、維修改正與架構手冊（標準英文檔名） |
| `黑膠播放器_使用者操作手冊.md` | 使用者操作手冊（繁體中文檔名，方便本機直接點開） |
| `黑膠播放器_完整開發維修改正手冊.md` | 開發維修改正手冊（繁體中文檔名，方便本機直接點開） |

### 2. 系統化文檔庫 (`docs/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `docs/01_使用者操作手冊.md` | 使用者操作指南（MP3 匯入、歌詞自動搜尋、桌面迷你播放器拖曳與 PWA 離線安裝步驟） |
| `docs/02_開發維修改正手冊.md` | 開發維修改正紀錄（14 大重大修復：切歌防中斷、ID 唯一匹配、雙軌存儲等） |
| `docs/03_架構與模組設計指南.md` | 系統架構圖 (Mermaid)、Hooks 狀態流、IndexedDB v4 資料庫綱要與 API 整合指南 |

### 3. 公共靜態資源與離線 PWA (`public/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `public/manifest.json` | PWA 漸進式網頁應用安裝清單（定義獨立全螢幕啟動、應用名稱與主題色） |
| `public/sw.js` | Service Worker 離線快取控制腳本（離線緩存靜態資源，斷網依然可用） |
| `public/favicon.svg` | 黑膠唱片造型向量網站圖標（Favicon） |
| `public/icons.svg` | 專案共用 SVG 向量圖標集合庫 |

### 4. 前端應用核心源碼 (`src/`)
#### 主入口與樣式
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `src/main.tsx` | React 應用程式根節點掛載入口檔案 |
| `src/App.tsx` | 全域主介面排版、狀態整合、頂部控制列、自訂重新命名與彈窗調度中心 |
| `src/App.css` | 黑膠唱片機旋轉、唱針擺動物理動畫與毛玻璃濾鏡效果樣式 |
| `src/index.css` | Tailwind CSS 基礎注入與全域自訂捲軸樣式 |

#### 靜態圖資 (`src/assets/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `src/assets/hero.png` | 預設唱片中心黑膠復古美術封面插圖 |
| `src/assets/react.svg` / `vite.svg` | 框架輔助向量資源 |

#### UI 互動元件 (`src/components/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `src/components/VinylRecord.tsx` | 擬真黑膠唱片機與唱針物理擺入/歸位旋轉動畫元件 |
| `src/components/MiniPlayer.tsx` | 280px 桌面寵物懸浮迷你黑膠播放器（自由拖曳、獨立音量、一鍵靜音） |
| `src/components/LyricViewer.tsx` | 置中動態 LRC 歌詞檢視器（毫秒級平滑滾動高亮） |
| `src/components/LyricModal.tsx` | 歌詞手動編輯與 LRCLIB 全球即時線上檢索彈窗 |
| `src/components/CoverModal.tsx` | 專輯封面自訂上傳與 Apple Music 官方高解析封面搜尋彈窗 |
| `src/components/PlaylistDrawer.tsx` | 抽屜式播放清單管理介面（自訂多清單、折疊收合 🔻/🔺） |
| `src/components/SortModal.tsx` | 歌曲排序方式切換選單（手動、歌名、新增日期、熱門次數） |
| `src/components/ListeningReportModal.tsx` | 個人聆聽習慣數據報告彈窗（播放次數、Top 5 最愛歌曲、歌手排行） |
| `src/components/ButtonSettingsModal.tsx` | 按鍵排序、外觀形狀（膠囊/卡片/方角）、主題與快捷鍵設定彈窗 |
| `src/components/FeedbackModal.tsx` | 用戶回饋管理中心（自適應寬度表格、密碼驗證 `0903`、裝置重點標籤、UTF-8 BOM CSV 匯出、Google 試算表 Webhook） |
| `src/components/BatchUploader.tsx` | 本機多首 MP3 批次拖曳讀取器（支援拖放與按鈕選取） |
| `src/components/YouTubeModal.tsx` | YouTube MV 網址正規化解析與嵌入播放彈窗 |

#### 核心業務邏輯 Hooks (`src/hooks/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `src/hooks/useAudioPlayer.ts` | 雙引擎音訊控制器（HTML5 Audio + YouTube API、音量、單曲/清單循環、切歌防中斷） |
| `src/hooks/usePlaylistManager.ts` | 清單佇列狀態管理、全域唯一歌曲 ID 匹配、播放次數統計、每月最愛自動聚合 |
| `src/hooks/useButtonSettings.ts` | 按鍵排列順序、外觀樣式主題、快捷鍵錄製綁定的 LocalStorage 持久化 |
| `src/hooks/useKeyboardShortcuts.ts` | 全域鍵盤快捷鍵無衝突監聽器（空白鍵播放、左右方向鍵切歌、M 鍵開關迷你黑膠） |

#### 核心工具模組 (`src/utils/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `src/utils/indexedDb.ts` | IndexedDB v4 本機永久資料庫（雙軌存儲機制，歌曲/清單/回饋零遺失） |
| `src/utils/deviceInfo.ts` | 裝置與瀏覽器環境精煉解析工具（將長 UA 萃取為重點標籤，如 `💻 Windows 10/11 · Chrome`） |
| `src/utils/feedbackExport.ts` | RFC 4180 CSV 試算表匯出模組（自動附帶 UTF-8 BOM，Excel 雙擊開啓絕無中文亂碼） |
| `src/utils/metadataParser.ts` | jsmediatags 二進位音訊標籤解析（讀取 MP3 內嵌封面 Blob、歌名、歌手） |
| `src/utils/lyricParser.ts` | 正則毫秒級動態 LRC 歌詞文字解析轉換工具 |
| `src/utils/lyricSearch.ts` | LRCLIB 全球開放動態歌詞 API 連線檢索工具 |
| `src/utils/coverSearch.ts` | Apple Music / iTunes API 官方高解析封面搜尋與 YouTube 縮圖解析 |
| `src/utils/shuffle.ts` | Fisher-Yates 嚴格真隨機洗牌演算法（消除隨機偏差） |
| `src/utils/formatTime.ts` | 秒數轉換為 `MM:SS` 格式化工具 |

#### 型別宣告與常數配置 (`src/types/` & `src/constants/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `src/types/song.ts` | 歌曲資料結構 (`SongItem`)、清單結構 (`Playlist`)、播放模式 (`PlaybackMode`) 型別 |
| `src/types/feedback.ts` | 回饋條目結構 (`FeedbackItem`) 與回饋分類 (`FeedbackType`) 型別 |
| `src/types/customButtons.ts` | 按鍵配置 (`TopButtonItemConfig`)、按鍵形狀、顏色主題、快捷鍵配置型別 |
| `src/types/jsmediatags.d.ts` | 二進位音訊標籤解析庫之 TypeScript 型別宣告 |
| `src/constants/themes.ts` | 播放器漸層外觀配色常數（星空黑膠、午夜藍、落日餘暉、深邃紫等） |

### 5. 自動化測試腳本 (`scripts/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `scripts/test-runner.mjs` | 端到端整合測試腳本（驗證 Vite 頁面交付、LRCLIB 歌詞 API、YouTube 網址正規化） |

### 6. 原生桌面版應用代碼 (`src-tauri/`)
| 檔案路徑 | 具體作用與用途說明 |
| :--- | :--- |
| `src-tauri/tauri.conf.json` | Tauri 桌面版視窗大小、自訂圖示、權限與安裝檔打包設定檔 |
| `src-tauri/Cargo.toml` / `Cargo.lock` | Rust 後端依賴庫宣告與精確版本鎖定檔 |
| `src-tauri/src/main.rs` / `src/lib.rs` | Tauri 桌面版底層生命週期啟動程式碼 |
| `src-tauri/build.rs` | Rust 原生桌面編譯建置腳本 |
| `src-tauri/capabilities/default.json` | Tauri 應用程式桌面權限安全性配置清單 |
| `src-tauri/icons/` | 多種解析度之 Windows (.ico) / macOS (.icns) 應用程式桌面圖標庫 |

---

## ⌨️ 全域鍵盤快捷鍵指南 (Keyboard Shortcuts)

> 💡 **小提示**：所有快捷鍵皆可在頂部的「**⚙️ 調整按鍵**」視窗中隨意變更錄入！

| 預設按鍵 | 觸發功能 | 支援自訂 |
| :--- | :--- | :--- |
| **空白鍵 (Space)** | 播放 / 暫停切換 | ✅ 支援 |
| **方向鍵向右 (→)** | 切換至下一首歌曲 | ✅ 支援 |
| **方向鍵向左 (←)** | 切換至上一首歌曲 | ✅ 支援 |
| **M 鍵 (KeyM)** | 開啟 / 關閉桌面迷你黑膠 | ✅ 支援 |

---

## 🚀 快速上手與開發指南 (Quick Start)

### 1. 環境需求
* **Node.js**：v18.0 或以上
* **npm**：v9.0 或以上（或使用 yarn / pnpm）

### 2. 安裝依賴
```powershell
npm install
```

### 3. 本地開發伺服器 (Web 瀏覽器版)
```powershell
npm run dev
```
啟動後打開瀏覽器訪問 [http://localhost:5173/](http://localhost:5173/) 即可立即體驗！

### 4. 執行自動化測試
專案內建專屬自動化驗證腳本，測試模組交付、歌詞 API 與正規化邏輯：
```powershell
node scripts/test-runner.mjs
```

### 5. 正式環境編譯 (Web Build)
```powershell
npm run build
```
構建完成的靜態網頁檔案位於 `dist/`，可一鍵部署至 **Vercel**、**GitHub Pages**、**Netlify** 或任何靜態主機。

### 6. 原生桌面版打包 (Tauri Desktop App)
若安裝有 Rust 環境與 C++ 建置工具，可直接編譯原生桌面安裝檔：
```powershell
npm run tauri build
```
產生的 Windows 原生安裝檔（`.msi` / `.exe`）將輸出於 `src-tauri/target/release/bundle/nsis/`。

---

## 🔒 隱私安全承諾 (Privacy & Security)

1. **零第三方追蹤與廣告**：本專案無任何廣告嵌入代碼，無任何第三方商業資料追蹤腳本。
2. **純本地離線存儲**：使用者上傳的 MP3 音樂、封面圖片與建立的播放清單皆直接存放於使用者自己的電腦瀏覽器（IndexedDB v4）中，未經授權絕不上傳任何第三方私有伺服器。
3. **回饋管理隱私保護**：用戶回饋管理後台嚴格受專屬密碼保護（預設 `0903`，可自訂），一般訪客完全無法查看任何人的留言記錄。

---

## 📄 版權與授權宣告 (License & Acknowledgement)

* **產品設計與全端架構開發**：Designed & Built by **温采穎** & **蔡懷萱**
* **授權方式**：開源發布於 **[MIT License](LICENSE)**，歡迎自由學習、研究、Fork 與二次擴充。
* **致謝開放 API**：感謝 [LRCLIB](https://lrclib.net/) 提供全球開源動態歌詞資料庫服務。

---

<div align="center">
  <b>Made with ❤️ and Vinyl Passion by 温采穎 & 蔡懷萱</b>
</div>
