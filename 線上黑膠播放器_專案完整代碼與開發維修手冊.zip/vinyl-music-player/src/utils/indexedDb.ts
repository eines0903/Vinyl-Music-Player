import type { SongItem, Playlist } from '../types/song';
import type { FeedbackItem } from '../types/feedback';

const DB_NAME = 'VinylMusicPlayerDB';
const DB_VERSION = 4;
const STORE_NAME = 'songs';
const PLAYLISTS_STORE = 'playlists';
const FEEDBACK_STORE = 'feedback';

interface StoredSongRecord {
  id: string;
  title: string;
  artist: string;
  audioBlob?: Blob;
  audioUrl?: string;
  coverUrl: string;
  lrcContent: string;
  youtubeId?: string;
  addedAt: number;
  playCount?: number;
  lastPlayedAt?: number;
  releaseDate?: string;
}

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(PLAYLISTS_STORE)) {
        db.createObjectStore(PLAYLISTS_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(FEEDBACK_STORE)) {
        db.createObjectStore(FEEDBACK_STORE, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

export const saveSongToDB = async (song: SongItem, file?: File | Blob): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);

    const record: StoredSongRecord = {
      id: song.id,
      title: song.title,
      artist: song.artist,
      audioBlob: file,
      audioUrl: song.audioUrl,
      coverUrl: song.coverUrl,
      lrcContent: song.lrcContent,
      addedAt: song.addedAt || Date.now(),
      playCount: song.playCount || 0,
      lastPlayedAt: song.lastPlayedAt,
      releaseDate: song.releaseDate,
    };

    const req = store.put(record);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
};

export const updateSongInDB = async (id: string, updates: Partial<StoredSongRecord>): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(id);

    getReq.onsuccess = () => {
      if (getReq.result) {
        const updated = { ...getReq.result, ...updates };
        const putReq = store.put(updated);
        putReq.onsuccess = () => resolve();
        putReq.onerror = () => reject(putReq.error);
      } else {
        resolve();
      }
    };
    getReq.onerror = () => reject(getReq.error);
  });
};

export const recordSongPlay = async (id: string): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(id);

    getReq.onsuccess = () => {
      if (getReq.result) {
        const currentCount = getReq.result.playCount || 0;
        const updated: StoredSongRecord = {
          ...getReq.result,
          playCount: currentCount + 1,
          lastPlayedAt: Date.now(),
        };
        const putReq = store.put(updated);
        putReq.onsuccess = () => resolve();
        putReq.onerror = () => reject(putReq.error);
      } else {
        resolve();
      }
    };
    getReq.onerror = () => reject(getReq.error);
  });
};

export const deleteSongFromDB = async (id: string): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
};

export const loadAllSongsFromDB = async (): Promise<SongItem[]> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.getAll();

    req.onsuccess = () => {
      const records = req.result as StoredSongRecord[];
      const songs: SongItem[] = records
        .map((r) => {
          let audioUrl = r.audioUrl || '';
          if (r.audioBlob) {
            audioUrl = URL.createObjectURL(r.audioBlob);
          }
          // 自動從 legacy id 還原遺失的 YouTube 連結
          if (!audioUrl) {
            const ytMatch = r.id.match(/^yt-([a-zA-Z0-9_-]{11})/);
            if (ytMatch) {
              audioUrl = `https://www.youtube.com/watch?v=${ytMatch[1]}`;
            }
          }
          return {
            id: r.id,
            title: r.title,
            artist: r.artist,
            audioUrl,
            coverUrl: r.coverUrl,
            lrcContent: r.lrcContent,
            addedAt: r.addedAt || Date.now(),
            playCount: r.playCount || 0,
            lastPlayedAt: r.lastPlayedAt,
            releaseDate: r.releaseDate,
          };
        })
        .filter((s) => Boolean(s.audioUrl));

      resolve(songs);
    };

    req.onerror = () => reject(req.error);
  });
};

// ======================== 自訂播放清單儲存 ========================

export const savePlaylistToDB = async (playlist: Playlist): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PLAYLISTS_STORE, 'readwrite');
    const store = tx.objectStore(PLAYLISTS_STORE);
    const req = store.put(playlist);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
};

export const loadAllPlaylistsFromDB = async (): Promise<Playlist[]> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PLAYLISTS_STORE, 'readonly');
    const store = tx.objectStore(PLAYLISTS_STORE);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result as Playlist[]);
    req.onerror = () => reject(req.error);
  });
};

export const deletePlaylistFromDB = async (id: string): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(PLAYLISTS_STORE, 'readwrite');
    const store = tx.objectStore(PLAYLISTS_STORE);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
};

// ======================== 用戶回饋問題儲存與管理 (支援 LocalStorage 雙重保證備援) ========================

const LOCAL_FEEDBACK_KEY = 'vinyl_player_feedback_backup_v1';

export const saveFeedbackToDB = async (feedback: FeedbackItem): Promise<void> => {
  // 1. 同步存入 LocalStorage 作為 100% 絕對備援 (即使資料庫被阻擋也保證成功)
  try {
    const existing = JSON.parse(localStorage.getItem(LOCAL_FEEDBACK_KEY) || '[]');
    const updated = [feedback, ...existing.filter((item: FeedbackItem) => item.id !== feedback.id)];
    localStorage.setItem(LOCAL_FEEDBACK_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn('localStorage backup warning:', e);
  }

  // 2. 存入 IndexedDB
  try {
    const db = await openDB();
    if (!db.objectStoreNames.contains(FEEDBACK_STORE)) {
      return;
    }
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(FEEDBACK_STORE, 'readwrite');
        const store = tx.objectStore(FEEDBACK_STORE);
        const req = store.put(feedback);
        req.onsuccess = () => resolve();
        req.onerror = () => resolve(); // 已有 LocalStorage 備援，不拋出錯誤
      } catch (err) {
        console.warn('IndexedDB transaction error:', err);
        resolve();
      }
    });
  } catch (e) {
    console.warn('openDB for feedback warning:', e);
  }
};

export const loadAllFeedbackFromDB = async (): Promise<FeedbackItem[]> => {
  let localItems: FeedbackItem[] = [];
  try {
    localItems = JSON.parse(localStorage.getItem(LOCAL_FEEDBACK_KEY) || '[]');
  } catch (e) {
    console.warn('Failed to parse local feedback backup:', e);
  }

  try {
    const db = await openDB();
    if (!db.objectStoreNames.contains(FEEDBACK_STORE)) {
      return localItems;
    }
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(FEEDBACK_STORE, 'readonly');
        const store = tx.objectStore(FEEDBACK_STORE);
        const req = store.getAll();
        req.onsuccess = () => {
          const dbItems = (req.result as FeedbackItem[]) || [];
          // 聚合 IndexedDB 與 LocalStorage，依 ID 去重
          const map = new Map<string, FeedbackItem>();
          [...dbItems, ...localItems].forEach((item) => {
            if (item && item.id) map.set(item.id, item);
          });
          const all = Array.from(map.values());
          all.sort((a, b) => b.createdAt - a.createdAt);
          resolve(all);
        };
        req.onerror = () => resolve(localItems);
      } catch (e) {
        resolve(localItems);
      }
    });
  } catch (e) {
    return localItems;
  }
};

export const deleteFeedbackFromDB = async (id: string): Promise<void> => {
  try {
    const existing = JSON.parse(localStorage.getItem(LOCAL_FEEDBACK_KEY) || '[]');
    const updated = existing.filter((item: FeedbackItem) => item.id !== id);
    localStorage.setItem(LOCAL_FEEDBACK_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn('delete from localStorage error:', e);
  }

  try {
    const db = await openDB();
    if (db.objectStoreNames.contains(FEEDBACK_STORE)) {
      const tx = db.transaction(FEEDBACK_STORE, 'readwrite');
      tx.objectStore(FEEDBACK_STORE).delete(id);
    }
  } catch (e) {
    console.warn('delete from IndexedDB error:', e);
  }
};

export const clearAllFeedbackFromDB = async (): Promise<void> => {
  localStorage.removeItem(LOCAL_FEEDBACK_KEY);
  try {
    const db = await openDB();
    if (db.objectStoreNames.contains(FEEDBACK_STORE)) {
      const tx = db.transaction(FEEDBACK_STORE, 'readwrite');
      tx.objectStore(FEEDBACK_STORE).clear();
    }
  } catch (e) {
    console.warn('clear IndexedDB error:', e);
  }
};

