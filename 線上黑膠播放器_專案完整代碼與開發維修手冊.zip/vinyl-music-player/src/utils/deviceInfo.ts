/**
 * 裝置與瀏覽器環境精簡解析模組 (顯示重點)
 * 將冗長的 User-Agent (例如 Mozilla/5.0 (Windows NT 10.0; Win64; x64)...)
 * 精煉為直觀重點：如「💻 Windows · Chrome (電腦)」、「📱 iOS · Safari (手機)」
 */

export interface ParsedDeviceInfo {
  os: string;
  browser: string;
  deviceType: 'desktop' | 'mobile' | 'tablet';
  deviceIcon: string;
  deviceLabel: string;
  shortSummary: string; // 例如: "Windows · Chrome"
  fullSummary: string;  // 例如: "💻 Windows · Chrome (電腦)"
}

export function parseDeviceInfo(uaString?: string): ParsedDeviceInfo {
  const ua = uaString || (typeof navigator !== 'undefined' ? navigator.userAgent : '');

  if (!ua || typeof ua !== 'string') {
    return {
      os: '未知系統',
      browser: '未知瀏覽器',
      deviceType: 'desktop',
      deviceIcon: '💻',
      deviceLabel: '電腦',
      shortSummary: '未知裝置',
      fullSummary: '💻 未知裝置',
    };
  }

  // 1. 判斷裝置型態 (Device Category)
  let deviceType: 'desktop' | 'mobile' | 'tablet' = 'desktop';
  let deviceIcon = '💻';
  let deviceLabel = '電腦';

  if (/tablet|ipad|playbook|silk/i.test(ua)) {
    deviceType = 'tablet';
    deviceIcon = '📟';
    deviceLabel = '平板';
  } else if (/mobile|iphone|ipod|android.*mobile|blackberry|phone|huawei/i.test(ua)) {
    deviceType = 'mobile';
    deviceIcon = '📱';
    deviceLabel = '手機';
  }

  // 2. 判斷作業系統 (OS)
  let os = '未知系統';
  if (/Windows NT 10\.0/i.test(ua)) {
    os = 'Windows 10/11';
  } else if (/Windows NT 6\.3/i.test(ua)) {
    os = 'Windows 8.1';
  } else if (/Windows NT 6\.1/i.test(ua)) {
    os = 'Windows 7';
  } else if (/Windows/i.test(ua)) {
    os = 'Windows';
  } else if (/iPhone/i.test(ua)) {
    os = 'iOS (iPhone)';
  } else if (/iPad/i.test(ua)) {
    os = 'iPadOS';
  } else if (/Mac OS X|Macintosh/i.test(ua)) {
    os = 'macOS';
  } else if (/Android/i.test(ua)) {
    const v = ua.match(/Android\s([0-9.]+)/i);
    os = v ? `Android ${v[1].split('.')[0]}` : 'Android';
  } else if (/CrOS/i.test(ua)) {
    os = 'ChromeOS';
  } else if (/Linux/i.test(ua)) {
    os = 'Linux';
  }

  // 3. 判斷瀏覽器 (Browser)
  let browser = '其他瀏覽器';
  if (/Edg\/([0-9.]+)/i.test(ua)) {
    browser = 'Edge';
  } else if (/OPR\/([0-9.]+)|Opera/i.test(ua)) {
    browser = 'Opera';
  } else if (/Brave/i.test(ua)) {
    browser = 'Brave';
  } else if (/Chrome\/([0-9.]+)/i.test(ua)) {
    browser = 'Chrome';
  } else if (/Version\/([0-9.]+).*Safari/i.test(ua)) {
    browser = 'Safari';
  } else if (/Firefox\/([0-9.]+)/i.test(ua)) {
    browser = 'Firefox';
  }

  const shortSummary = `${os} · ${browser}`;
  const fullSummary = `${deviceIcon} ${os} · ${browser} (${deviceLabel})`;

  return {
    os,
    browser,
    deviceType,
    deviceIcon,
    deviceLabel,
    shortSummary,
    fullSummary,
  };
}
