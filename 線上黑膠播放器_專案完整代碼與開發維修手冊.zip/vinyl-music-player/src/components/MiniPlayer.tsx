import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import type { SongItem, PlaybackMode } from '../types/song';
import { formatTime } from '../utils/formatTime';

interface MiniPlayerProps {
  playerName?: string;
  currentSong: SongItem | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  playbackMode: PlaybackMode;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onSeek?: (time: number) => void;
  onVolumeChange: (volume: number) => void;
  onToggleMute: () => void;
  onTogglePlaybackMode: () => void;
  onExpand: () => void;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({
  playerName = '桌面迷你黑膠',
  currentSong,
  isPlaying,
  currentTime,
  duration,
  volume,
  isMuted,
  playbackMode,
  onTogglePlay,
  onNext,
  onPrev,
  onSeek,
  onVolumeChange,
  onToggleMute,
  onTogglePlaybackMode,
  onExpand,
}) => {
  // 1. 視窗位置 (支援持久化記憶)
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    try {
      const saved = localStorage.getItem('vinyl_mini_pos');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.x === 'number' && typeof parsed.y === 'number') {
          return {
            x: Math.min(Math.max(10, parsed.x), window.innerWidth - 100),
            y: Math.min(Math.max(10, parsed.y), window.innerHeight - 100),
          };
        }
      }
    } catch (e) {
      // ignore
    }
    const initialX = Math.max(20, window.innerWidth - 330);
    const initialY = Math.max(20, window.innerHeight - 240);
    return { x: initialX, y: initialY };
  });

  // 2. 視窗寬度自由調整 (210px ~ 480px，支援記憶)
  const [width, setWidth] = useState<number>(() => {
    const saved = localStorage.getItem('vinyl_mini_width');
    const parsed = saved ? parseInt(saved, 10) : 290;
    return isNaN(parsed) ? 290 : Math.min(Math.max(210, parsed), 480);
  });

  // 3. 一鍵縮小成懸浮泡泡/膠囊
  const [isMinimized, setIsMinimized] = useState<boolean>(() => {
    return localStorage.getItem('vinyl_mini_minimized') === 'true';
  });

  // 4. 原生桌面 Picture-in-Picture 視窗實例 (真·飄在 Windows 桌面上)
  const [pipWindow, setPipWindow] = useState<Window | null>(null);

  // 拖曳位置邏輯
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: 0,
    posY: 0,
  });

  // 縮放大小邏輯
  const [isResizing, setIsResizing] = useState(false);
  const resizeStartRef = useRef<{ startX: number; startWidth: number }>({
    startX: 0,
    startWidth: 290,
  });

  // 儲存位置
  useEffect(() => {
    localStorage.setItem('vinyl_mini_pos', JSON.stringify(position));
  }, [position]);

  // 儲存寬度
  useEffect(() => {
    localStorage.setItem('vinyl_mini_width', width.toString());
  }, [width]);

  // 儲存縮小狀態
  useEffect(() => {
    localStorage.setItem('vinyl_mini_minimized', isMinimized ? 'true' : 'false');
  }, [isMinimized]);

  // 拖曳移動視窗
  const handleMouseDownDrag = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, input, .resize-handle, .seek-bar')) return;
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: position.x,
      posY: position.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        const dx = e.clientX - dragStartRef.current.startX;
        const dy = e.clientY - dragStartRef.current.startY;
        const maxX = window.innerWidth - (isMinimized ? 60 : width);
        const maxY = window.innerHeight - (isMinimized ? 60 : 160);
        const newX = Math.min(Math.max(10, dragStartRef.current.posX + dx), Math.max(10, maxX));
        const newY = Math.min(Math.max(10, dragStartRef.current.posY + dy), Math.max(10, maxY));
        setPosition({ x: newX, y: newY });
      }

      if (isResizing) {
        const dx = e.clientX - resizeStartRef.current.startX;
        const newWidth = Math.min(Math.max(210, resizeStartRef.current.startWidth + dx), 480);
        setWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
    };

    if (isDragging || isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, width, isMinimized]);

  // 啟動自由拖曳縮放大小
  const handleMouseDownResize = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setIsResizing(true);
    resizeStartRef.current = {
      startX: e.clientX,
      startWidth: width,
    };
  };

  // 尺寸規格快捷切換
  const handleSetPresetWidth = (targetWidth: number) => {
    setWidth(targetWidth);
  };

  // 進度條快轉/倒轉 (點擊跳轉)
  const handleSeekClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!duration || !onSeek) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percent = Math.min(Math.max(0, clickX / rect.width), 1);
    onSeek(percent * duration);
  };

  // 🖥️ 開啟原生桌面 Picture-in-Picture 置頂視窗 (真·飄在 Windows 桌面上)
  const handleTogglePip = async () => {
    if (pipWindow) {
      pipWindow.close();
      setPipWindow(null);
      return;
    }

    if ('documentPictureInPicture' in window) {
      try {
        const pip = await (window as any).documentPictureInPicture.requestWindow({
          width: Math.min(width, 360),
          height: width < 260 ? 120 : 210,
        });

        // 複製主視窗所有 CSS 樣式與 Tailwind 配置
        [...document.styleSheets].forEach((styleSheet) => {
          try {
            const cssRules = [...styleSheet.cssRules].map((rule) => rule.cssText).join('');
            const style = pip.document.createElement('style');
            style.textContent = cssRules;
            pip.document.head.appendChild(style);
          } catch (e) {
            const link = pip.document.createElement('link');
            if (styleSheet.href) {
              link.rel = 'stylesheet';
              link.type = styleSheet.type;
              link.media = styleSheet.media;
              link.href = styleSheet.href;
              pip.document.head.appendChild(link);
            }
          }
        });

        pip.document.body.className =
          'bg-zinc-950 text-white select-none overflow-hidden m-0 p-3 flex items-center justify-center min-h-screen font-sans';
        pip.document.title = `${playerName} - 桌面置頂黑膠`;

        pip.addEventListener('pagehide', () => {
          setPipWindow(null);
        });

        setPipWindow(pip);
      } catch (err) {
        console.warn('開啟桌面 Picture-in-Picture 失敗:', err);
        alert('未能開啟桌面置頂視窗，將維持在瀏覽器內漂浮。');
      }
    } else {
      alert(
        '💡 您的瀏覽器尚未原生支援 Document Picture-in-Picture API。\n建議使用最新版 Google Chrome 或 Microsoft Edge，即可一鍵將小黑膠獨立飄在 Windows 桌面上！'
      );
    }
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const isCompact = width < 250;
  const isExpanded = width >= 340;

  // 迷你黑膠內容核心渲染 (同時支援在網頁內漂浮或透過 Portal 飄在 PiP 桌面視窗)
  const renderPlayerContent = (inPip: boolean = false) => {
    return (
      <div
        style={inPip ? { width: '100%', height: '100%' } : { width: `${width}px` }}
        className={`bg-zinc-900/95 backdrop-blur-2xl border border-zinc-700/80 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.85)] p-3 text-white select-none transition-shadow relative group ${
          isDragging ? 'cursor-grabbing shadow-indigo-500/30' : 'cursor-grab'
        } ${isResizing ? 'ring-2 ring-indigo-500/50' : ''}`}
      >
        {/* 頂部操作列：視窗控制、尺寸規格、桌面置頂按鈕 */}
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800/80">
          <div className="flex items-center gap-1.5 min-w-0 max-w-[140px]">
            <span
              className={`w-2 h-2 rounded-full shrink-0 ${
                isPlaying ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
              }`}
            />
            <span
              className="text-[10px] font-bold tracking-wider text-zinc-300 truncate"
              title={playerName}
            >
              {playerName}
            </span>
          </div>

          <div className="flex items-center gap-1">
            {/* 3 種尺寸預設一鍵調整 */}
            {!inPip && (
              <div className="flex items-center bg-zinc-800/80 rounded-lg p-0.5 border border-zinc-700/50 text-[9px]">
                <button
                  type="button"
                  onClick={() => handleSetPresetWidth(220)}
                  className={`px-1.5 py-0.5 rounded transition ${
                    isCompact ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                  title="💊 微型迷你膠囊 (220px)"
                >
                  微型
                </button>
                <button
                  type="button"
                  onClick={() => handleSetPresetWidth(290)}
                  className={`px-1.5 py-0.5 rounded transition ${
                    !isCompact && !isExpanded
                      ? 'bg-indigo-600 text-white font-bold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                  title="🎵 標準黑膠 (290px)"
                >
                  標準
                </button>
                <button
                  type="button"
                  onClick={() => handleSetPresetWidth(370)}
                  className={`px-1.5 py-0.5 rounded transition ${
                    isExpanded ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-400 hover:text-white'
                  }`}
                  title="🎛️ 展開細節 (370px)"
                >
                  寬大
                </button>
              </div>
            )}

            {/* 🖥️ 飄在桌面 (Picture-in-Picture 桌面置頂) */}
            <button
              type="button"
              onClick={handleTogglePip}
              className={`p-1 rounded-lg transition ${
                inPip
                  ? 'text-amber-400 bg-amber-400/20'
                  : 'text-zinc-400 hover:text-amber-300 hover:bg-zinc-800'
              }`}
              title={inPip ? '放回網頁中' : '🖥️ 飄在桌面 (彈出為獨立置頂視窗)'}
            >
              <span className="text-xs">🖥️</span>
            </button>

            {/* 縮小成懸浮泡泡 */}
            {!inPip && (
              <button
                type="button"
                onClick={() => setIsMinimized(true)}
                className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
                title="縮小成懸浮小唱片泡泡"
              >
                <span className="text-xs font-bold leading-none">—</span>
              </button>
            )}

            {/* 還原主畫面 */}
            <button
              type="button"
              onClick={onExpand}
              className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
              title="展開回完整播放器"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z" />
              </svg>
            </button>
          </div>
        </div>

        {/* 迷你黑膠唱片 + 曲目資訊展示區 */}
        <div className="flex items-center gap-3">
          {/* 黑膠唱片本體 (具有等速平滑旋轉) */}
          <div
            className={`relative shrink-0 transition-all ${
              isCompact ? 'w-12 h-12' : isExpanded ? 'w-18 h-18' : 'w-14 h-14'
            }`}
          >
            <div
              className={`w-full h-full rounded-full bg-zinc-950 p-1 shadow-md border-2 border-zinc-800 flex items-center justify-center ${
                isPlaying ? 'animate-spin-slow' : ''
              }`}
              style={{ animationDuration: '4s' }}
            >
              {/* 同心圓凹槽 */}
              <div className="w-full h-full rounded-full border border-zinc-700/40 flex items-center justify-center overflow-hidden">
                {currentSong?.coverUrl ? (
                  <img
                    src={currentSong.coverUrl}
                    alt={currentSong.title}
                    className="w-full h-full rounded-full object-cover shadow"
                  />
                ) : (
                  <div className="w-full h-full rounded-full bg-gradient-to-tr from-indigo-500 to-rose-500 flex items-center justify-center text-xs">
                    🎵
                  </div>
                )}
              </div>
              {/* 中心孔 */}
              <div className="absolute w-2 h-2 rounded-full bg-zinc-900 border border-zinc-600" />
            </div>
          </div>

          {/* 歌曲資訊與互動進度條 */}
          <div className="min-w-0 flex-1 space-y-1">
            <div className="flex items-center justify-between gap-1">
              <p
                className="text-xs font-bold text-white truncate"
                title={currentSong?.title || '未在播放'}
              >
                {currentSong?.title || '尚未選擇歌曲'}
              </p>
              {currentSong?.audioUrl?.includes('youtu') && (
                <span className="text-[9px] bg-red-500/20 text-red-400 px-1 rounded font-mono shrink-0">
                  MV
                </span>
              )}
            </div>

            <p
              className="text-[10px] text-zinc-400 truncate"
              title={currentSong?.artist || ''}
            >
              {currentSong?.artist || 'Vinyl Music Player'}
            </p>

            {/* 可點擊快轉的互動進度條 */}
            <div
              onClick={handleSeekClick}
              className="seek-bar group/seek w-full py-1 cursor-pointer flex flex-col justify-center"
              title="點擊快轉 / 跳轉歌曲進度"
            >
              <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden relative">
                <div
                  className="bg-gradient-to-r from-indigo-500 to-amber-400 h-full rounded-full transition-all duration-150"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* 時間軸數值顯示 (標準與寬大模式顯示) */}
            {!isCompact && (
              <div className="flex justify-between text-[9px] text-zinc-500 font-mono">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            )}
          </div>
        </div>

        {/* 底部控制按鈕列 */}
        <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-zinc-800/80">
          {/* 循環模式切換按鈕 */}
          <button
            type="button"
            onClick={onTogglePlaybackMode}
            className={`p-1.5 rounded-lg text-xs transition ${
              playbackMode === 'loop-one'
                ? 'text-amber-400 bg-amber-400/15'
                : playbackMode === 'stop-after'
                ? 'text-rose-400 bg-rose-400/15'
                : 'text-indigo-400 bg-indigo-500/15'
            }`}
            title={
              playbackMode === 'loop-one'
                ? '單曲循環中 (點擊切換)'
                : playbackMode === 'stop-after'
                ? '播完此曲即停止 (點擊切換)'
                : '自動播放下一首 (點擊切換)'
            }
          >
            {playbackMode === 'loop-one' ? '🔂' : playbackMode === 'stop-after' ? '⏹️' : '🔁'}
          </button>

          {/* 上一首、播放/暫停、下一首 */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onPrev}
              className="p-1 text-zinc-400 hover:text-white transition active:scale-90"
              title="上一首"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z" />
              </svg>
            </button>

            <button
              type="button"
              onClick={onTogglePlay}
              className="p-2 rounded-full bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-400 hover:to-indigo-500 text-white shadow-md active:scale-95 transition"
              title="播放/暫停 (空白鍵)"
            >
              {isPlaying ? (
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                  <rect x="6" y="4" width="4" height="16" rx="1" />
                  <rect x="14" y="4" width="4" height="16" rx="1" />
                </svg>
              ) : (
                <svg className="w-3.5 h-3.5 fill-current translate-x-0.5" viewBox="0 0 24 24">
                  <path d="M5 3l14 9-14 9V3z" />
                </svg>
              )}
            </button>

            <button
              type="button"
              onClick={onNext}
              className="p-1 text-zinc-400 hover:text-white transition active:scale-90"
              title="下一首"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z" />
              </svg>
            </button>
          </div>

          {/* 音量控制 (超小模式僅顯示圖標，標準與寬大帶滑桿) */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onToggleMute}
              className="p-1 text-zinc-400 hover:text-white transition text-xs"
              title={isMuted ? '取消靜音' : '靜音'}
            >
              {isMuted || volume === 0 ? '🔇' : volume < 0.5 ? '🔉' : '🔊'}
            </button>

            {!isCompact && (
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
                className="w-12 h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                title={`音量: ${Math.round((isMuted ? 0 : volume) * 100)}%`}
              />
            )}
          </div>
        </div>

        {/* 右下角自由縮放握把 (Drag to Resize Handle) */}
        {!inPip && (
          <div
            onMouseDown={handleMouseDownResize}
            className="resize-handle absolute bottom-1 right-1 w-4 h-4 cursor-nwse-resize flex items-end justify-end p-0.5 text-zinc-600 hover:text-amber-400 transition"
            title="按住右下角自由拖曳調整視窗大小 (寬度 210px ~ 480px)"
          >
            <svg className="w-2.5 h-2.5 fill-current" viewBox="0 0 24 24">
              <path d="M22 22h-2v-2h2v2zm0-4h-2v-2h2v2zm-4 4h-2v-2h2v2zm0-4h-2v-2h2v2zm-4 4h-2v-2h2v2zm8-8h-2v-2h2v2z" />
            </svg>
          </div>
        )}
      </div>
    );
  };

  // 若使用者已開啟原生桌面 Picture-in-Picture 視窗，使用 React Portal 渲染進桌面視窗中
  if (pipWindow) {
    return (
      <>
        {createPortal(renderPlayerContent(true), pipWindow.document.body)}
        {/* 在主網頁中留下溫馨提示標籤 */}
        <div
          style={{ left: `${position.x}px`, top: `${position.y}px` }}
          className="fixed z-50 bg-zinc-900/90 border border-amber-500/50 rounded-2xl p-2 px-3 shadow-xl backdrop-blur-md flex items-center gap-2 text-xs text-amber-300 animate-pulse"
        >
          <span>🖥️</span>
          <span>迷你黑膠正置頂飄在桌面上</span>
          <button
            onClick={() => {
              pipWindow.close();
              setPipWindow(null);
            }}
            className="px-2 py-0.5 bg-amber-500 text-zinc-950 font-bold rounded-lg hover:bg-amber-400 transition text-[10px]"
          >
            放回網頁
          </button>
        </div>
      </>
    );
  }

  // 若使用者點擊縮小成「懸浮黑膠小泡泡」
  if (isMinimized) {
    return (
      <div
        style={{ left: `${position.x}px`, top: `${position.y}px` }}
        onMouseDown={handleMouseDownDrag}
        onDoubleClick={() => setIsMinimized(false)}
        className={`fixed z-50 select-none group transition-transform ${
          isDragging ? 'cursor-grabbing scale-105' : 'cursor-grab hover:scale-110'
        }`}
        title={`${currentSong?.title || '迷你黑膠'} (雙擊還原完整視窗)`}
      >
        <div className="relative w-14 h-14 rounded-full bg-zinc-900/95 border-2 border-amber-400/80 shadow-[0_10px_30px_rgba(0,0,0,0.8)] p-1 flex items-center justify-center">
          {/* 旋轉黑膠唱片 */}
          <div
            className={`w-full h-full rounded-full bg-zinc-950 flex items-center justify-center overflow-hidden border border-zinc-700 ${
              isPlaying ? 'animate-spin-slow' : ''
            }`}
            style={{ animationDuration: '4s' }}
          >
            {currentSong?.coverUrl ? (
              <img
                src={currentSong.coverUrl}
                alt={currentSong.title}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <span className="text-xs">🎵</span>
            )}
          </div>

          {/* 中心播放/暫停按鈕 */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onTogglePlay();
            }}
            className="absolute inset-0 m-auto w-6 h-6 rounded-full bg-black/60 hover:bg-black/90 backdrop-blur-sm text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition shadow"
            title="播放/暫停"
          >
            {isPlaying ? (
              <span className="text-[10px]">⏸</span>
            ) : (
              <span className="text-[10px] translate-x-0.5">▶</span>
            )}
          </button>

          {/* 還原大視窗小把手 */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsMinimized(false);
            }}
            className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center text-[10px] shadow-md border border-white/20 transition"
            title="還原為完整視窗"
          >
            ⤢
          </button>
        </div>
      </div>
    );
  }

  // 正常在網頁內自由漂浮
  return (
    <div
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
      onMouseDown={handleMouseDownDrag}
      className="fixed z-50"
    >
      {renderPlayerContent(false)}
    </div>
  );
};
