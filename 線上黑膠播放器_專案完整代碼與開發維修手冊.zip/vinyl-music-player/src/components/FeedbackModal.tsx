import React, { useState, useEffect, useMemo } from 'react';
import type { FeedbackItem, FeedbackType } from '../types/feedback';
import {
  saveFeedbackToDB,
  loadAllFeedbackFromDB,
  deleteFeedbackFromDB,
  clearAllFeedbackFromDB,
} from '../utils/indexedDb';
import { exportFeedbackToCSV } from '../utils/feedbackExport';
import { parseDeviceInfo } from '../utils/deviceInfo';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const FEEDBACK_TYPES: { type: FeedbackType; label: string; icon: string }[] = [
  { type: 'feature', label: '功能建議', icon: '💡' },
  { type: 'bug', label: '問題回報', icon: '🐞' },
  { type: 'song', label: '歌曲/歌詞', icon: '🎵' },
  { type: 'other', label: '其他回饋', icon: '💬' },
];

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'submit' | 'list'>('submit');
  const [viewMode, setViewMode] = useState<'table' | 'card'>('table');
  const [feedbackList, setFeedbackList] = useState<FeedbackItem[]>([]);
  const [loading, setLoading] = useState(false);

  // 管理員身分驗證 (預設密碼 0903，保證只有站長/作者能查看與匯出)
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('vinyl_admin_authenticated') === 'true';
  });
  const [showPasswordModal, setShowPasswordModal] = useState<boolean>(false);
  const [inputPassword, setInputPassword] = useState<string>('');
  const [passwordError, setPasswordError] = useState<string>('');

  const [adminPasscode, setAdminPasscode] = useState<string>(() => {
    return localStorage.getItem('vinyl_admin_passcode') || '0903';
  });
  const [isChangingPasscode, setIsChangingPasscode] = useState(false);
  const [newPasscode, setNewPasscode] = useState('');

  // 雲端即時同步 Webhook 網址 (可連動 Google Sheets / Formspree 等)
  const [webhookUrl, setWebhookUrl] = useState<string>(() => {
    return localStorage.getItem('vinyl_feedback_webhook_url') || '';
  });
  const [isEditingWebhook, setIsEditingWebhook] = useState(false);
  const [tempWebhook, setTempWebhook] = useState(webhookUrl);

  // 表單欄位狀態
  const [type, setType] = useState<FeedbackType>('feature');
  const [rating, setRating] = useState<number>(5);
  const [userName, setUserName] = useState<string>('');
  const [contact, setContact] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [lastSubmittedFeedback, setLastSubmittedFeedback] = useState<FeedbackItem | null>(null);

  // 試算表月份篩選器
  const currentMonthKey = new Date().toISOString().slice(0, 7); // e.g. "2026-10"
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthKey);

  // 讀取回饋清單
  const fetchFeedbacks = async () => {
    try {
      setLoading(true);
      const items = await loadAllFeedbackFromDB();
      setFeedbackList(items);
    } catch (err) {
      console.error('Failed to load feedbacks:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      if (isAdminAuthenticated) {
        fetchFeedbacks();
      }
      setSubmitSuccess(false);
      setPasswordError('');
      setInputPassword('');
      setShowPasswordModal(false);
    }
  }, [isOpen, isAdminAuthenticated]);

  // 鍵盤 Esc 關閉
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        if (showPasswordModal) {
          setShowPasswordModal(false);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, showPasswordModal, onClose]);

  // 提取所有有回饋的月份清單
  const availableMonths = useMemo(() => {
    const monthsSet = new Set<string>();
    monthsSet.add(currentMonthKey);
    feedbackList.forEach((item) => {
      if (item.monthKey) monthsSet.add(item.monthKey);
    });
    return Array.from(monthsSet).sort().reverse();
  }, [feedbackList, currentMonthKey]);

  // 根據月份篩選回饋
  const filteredFeedbacks = useMemo(() => {
    if (selectedMonth === 'all') return feedbackList;
    return feedbackList.filter((item) => item.monthKey === selectedMonth);
  }, [feedbackList, selectedMonth]);

  // 統計指標
  const stats = useMemo(() => {
    const target = selectedMonth === 'all' ? feedbackList : filteredFeedbacks;
    const total = target.length;
    const avgRating =
      total > 0 ? (target.reduce((acc, cur) => acc + cur.rating, 0) / total).toFixed(1) : '5.0';
    return { total, avgRating };
  }, [feedbackList, filteredFeedbacks, selectedMonth]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      alert('請填寫回饋或問題內容！');
      return;
    }

    try {
      setIsSubmitting(true);
      const now = new Date();
      const monthKey = now.toISOString().slice(0, 7); // "YYYY-MM"
      const typeObj = FEEDBACK_TYPES.find((t) => t.type === type);
      const deviceInfo = `${navigator.userAgent.slice(0, 100)}`;

      const newFeedback: FeedbackItem = {
        id: `fb_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        createdAt: Date.now(),
        monthKey,
        type,
        typeName: typeObj ? `${typeObj.icon} ${typeObj.label}` : '其他',
        rating,
        userName: userName.trim() || '熱心聽友',
        contact: contact.trim(),
        content: content.trim(),
        deviceInfo,
      };

      // 1. 本地儲存至 IndexedDB
      await saveFeedbackToDB(newFeedback);

      // 2. 若有設定雲端 Webhook (如 Google Apps Script)，同步轉發至 Google 試算表
      const savedWebhook = localStorage.getItem('vinyl_feedback_webhook_url');
      if (savedWebhook) {
        fetch(savedWebhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newFeedback),
          mode: 'no-cors',
        }).catch((err) => console.warn('雲端 Webhook 同步失敗:', err));
      }

      if (isAdminAuthenticated) {
        await fetchFeedbacks();
      }

      setLastSubmittedFeedback(newFeedback);
      setSubmitSuccess(true);
      setContent('');
    } catch (err) {
      console.error('Failed to submit feedback:', err);
      alert('提交失敗，請稍後再試！');
    } finally {
      setIsSubmitting(false);
    }
  };

  // 管理員密碼驗證
  const handleVerifyPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputPassword === adminPasscode) {
      setIsAdminAuthenticated(true);
      localStorage.setItem('vinyl_admin_authenticated', 'true');
      setShowPasswordModal(false);
      setInputPassword('');
      setPasswordError('');
      setActiveTab('list');
      fetchFeedbacks();
    } else {
      setPasswordError('❌ 管理員密碼錯誤，請重新輸入！');
    }
  };

  // 登出管理員身分
  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('vinyl_admin_authenticated');
    setActiveTab('submit');
  };

  // 修改管理員密碼
  const handleChangePasscode = () => {
    if (!newPasscode.trim()) {
      alert('新密碼不可為空！');
      return;
    }
    setAdminPasscode(newPasscode.trim());
    localStorage.setItem('vinyl_admin_passcode', newPasscode.trim());
    setIsChangingPasscode(false);
    setNewPasscode('');
    alert('管理員密碼已成功更新！');
  };

  // 儲存雲端同步網址
  const handleSaveWebhook = () => {
    setWebhookUrl(tempWebhook.trim());
    localStorage.setItem('vinyl_feedback_webhook_url', tempWebhook.trim());
    setIsEditingWebhook(false);
    alert('雲端同步 Webhook 網址已儲存！');
  };

  const handleDeleteItem = async (id: string) => {
    if (window.confirm('確定要刪除這筆回饋嗎？')) {
      await deleteFeedbackFromDB(id);
      await fetchFeedbacks();
    }
  };

  const handleClearAll = async () => {
    if (window.confirm('確定要清空所有的用戶回饋嗎？此動作無法復原。')) {
      await clearAllFeedbackFromDB();
      await fetchFeedbacks();
    }
  };

  const handleExportSpreadsheet = () => {
    exportFeedbackToCSV(feedbackList, selectedMonth);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in select-none">
      <div
        className={`bg-zinc-900 border border-zinc-700/80 rounded-3xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-white relative transition-all duration-300 ${
          activeTab === 'list' ? 'max-w-4xl' : 'max-w-2xl'
        }`}
      >
        {/* 頂部標頭列 */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <span className="text-xl">💬</span>
            <div>
              <h2 className="text-lg font-bold tracking-wide">用戶回饋與問題回報</h2>
              <p className="text-[11px] text-zinc-400">
                {isAdminAuthenticated
                  ? '👑 管理員模式已解鎖：可查看所有回饋並匯出每月試算表'
                  : '歡迎留下您的問題、操作心得或功能建議'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isAdminAuthenticated && (
              <button
                onClick={handleAdminLogout}
                className="text-[11px] px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg border border-zinc-700 transition flex items-center gap-1"
                title="登出管理員身分"
              >
                <span>🔒</span>
                <span>登出管理員</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="text-zinc-400 hover:text-white p-1 rounded-full hover:bg-zinc-800 transition"
              title="關閉 (Esc)"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* 標籤切換列 */}
        <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-950/40 px-6 pt-2">
          <div className="flex">
            <button
              onClick={() => setActiveTab('submit')}
              className={`py-3 px-4 font-semibold text-xs border-b-2 transition flex items-center gap-2 ${
                activeTab === 'submit'
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <span>✍️ 填寫回饋問題</span>
            </button>

            {isAdminAuthenticated ? (
              <button
                onClick={() => {
                  setActiveTab('list');
                  fetchFeedbacks();
                }}
                className={`py-3 px-4 font-semibold text-xs border-b-2 transition flex items-center gap-2 ${
                  activeTab === 'list'
                    ? 'border-amber-400 text-amber-300'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <span>📊 回饋管理與試算表匯出</span>
                {feedbackList.length > 0 && (
                  <span className="px-2 py-0.5 text-[10px] bg-amber-500/20 text-amber-300 rounded-full border border-amber-500/30">
                    {feedbackList.length}
                  </span>
                )}
              </button>
            ) : (
              <button
                onClick={() => setShowPasswordModal(true)}
                className="py-3 px-4 font-medium text-xs text-zinc-500 hover:text-amber-400 transition flex items-center gap-1.5"
                title="輸入管理員密碼以查看後台與匯出試算表"
              >
                <span>🔐</span>
                <span>管理員後台 (需密碼)</span>
              </button>
            )}
          </div>

          <div className="text-[11px] text-zinc-500">
            {isAdminAuthenticated ? (
              <span className="text-emerald-400 flex items-center gap-1 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                管理員授權中
              </span>
            ) : (
              <span className="text-zinc-500">訪客模式</span>
            )}
          </div>
        </div>

        {/* 標籤內容展示區 */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'submit' ? (
            /* 填寫回饋表單 */
            <form onSubmit={handleSubmit} className="space-y-5">
              {submitSuccess && lastSubmittedFeedback ? (
                <div className="p-6 bg-gradient-to-b from-emerald-950/40 to-zinc-900 border border-emerald-500/40 rounded-2xl animate-fade-in space-y-5">
                  <div className="text-center space-y-2">
                    <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 text-3xl mb-1 ring-4 ring-emerald-500/10">
                      ✓
                    </div>
                    <h3 className="text-lg font-bold text-emerald-400">回饋已成功寄出與保存！</h3>
                    <p className="text-xs text-zinc-300 max-w-md mx-auto">
                      您的意見已完成雙重安全保存（本機 IndexedDB 與 LocalStorage 雙軌備份），並已記錄至系統後台。
                    </p>
                  </div>

                  {/* 回饋詳細憑證清單 */}
                  <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-4 text-xs space-y-2.5 text-zinc-300">
                    <div className="flex justify-between items-center pb-2 border-b border-zinc-800">
                      <span className="text-zinc-400">回饋時間</span>
                      <span className="font-mono text-[11px] text-zinc-400">
                        {new Date(lastSubmittedFeedback.createdAt).toLocaleString('zh-TW')}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-zinc-400">類型 & 滿意度</span>
                      <span className="font-semibold text-amber-300 flex items-center gap-1.5">
                        {lastSubmittedFeedback.typeName}
                        <span>•</span>
                        <span>{'⭐'.repeat(lastSubmittedFeedback.rating)}</span>
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-zinc-400">暱稱 / 聯絡方式</span>
                      <span className="text-zinc-200">
                        {lastSubmittedFeedback.userName} {lastSubmittedFeedback.contact ? `(${lastSubmittedFeedback.contact})` : ''}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-zinc-400">環境重點</span>
                      <span className="text-amber-300 font-mono text-[11px] bg-zinc-950/80 px-2 py-0.5 rounded border border-zinc-800">
                        {parseDeviceInfo(lastSubmittedFeedback.deviceInfo).fullSummary}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-zinc-800/80">
                      <div className="text-zinc-400 mb-1">回饋內容：</div>
                      <div className="p-2.5 bg-zinc-950/60 rounded-lg text-zinc-200 text-xs whitespace-pre-wrap max-h-32 overflow-y-auto leading-relaxed border border-zinc-800/50">
                        {lastSubmittedFeedback.content}
                      </div>
                    </div>
                  </div>

                  {/* 快捷操作按鈕組 */}
                  <div className="space-y-2 pt-1">
                    {!isAdminAuthenticated ? (
                      <button
                        type="button"
                        onClick={() => setShowPasswordModal(true)}
                        className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2"
                      >
                        <span>👑 我是管理員：解鎖後台查看此筆回饋與匯出</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab('list');
                          fetchFeedbacks();
                        }}
                        className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2"
                      >
                        <span>📊 切換至管理員後台查看這筆回饋</span>
                      </button>
                    )}

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setSubmitSuccess(false);
                          setLastSubmittedFeedback(null);
                        }}
                        className="py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition flex items-center justify-center gap-1.5"
                      >
                        <span>✍️ 再填寫一則</span>
                      </button>
                      <button
                        type="button"
                        onClick={onClose}
                        className="py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium transition flex items-center justify-center gap-1.5"
                      >
                        <span>✓ 完成並關閉</span>
                      </button>
                    </div>

                    <a
                      href={`mailto:service@vinylplayer.local?subject=${encodeURIComponent(`[黑膠播放器回饋] ${lastSubmittedFeedback.typeName}`)}&body=${encodeURIComponent(`暱稱: ${lastSubmittedFeedback.userName}\n聯絡方式: ${lastSubmittedFeedback.contact}\n評分: ${lastSubmittedFeedback.rating}星\n\n內容:\n${lastSubmittedFeedback.content}\n\n時間: ${new Date(lastSubmittedFeedback.createdAt).toLocaleString()}`)}`}
                      className="block text-center text-[11px] text-zinc-400 hover:text-amber-300 pt-2 transition underline underline-offset-4"
                    >
                      📧 想要以 Email 另外備份傳送給管理員？點此開啟郵件軟體
                    </a>
                  </div>
                </div>
              ) : (
                <>
                  {/* 回饋類型選擇 */}
                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-2">回饋類型</label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {FEEDBACK_TYPES.map((t) => (
                        <button
                          key={t.type}
                          type="button"
                          onClick={() => setType(t.type)}
                          className={`py-2 px-3 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 transition ${
                            type === t.type
                              ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-sm'
                              : 'bg-zinc-800/60 border-zinc-700/80 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200'
                          }`}
                        >
                          <span>{t.icon}</span>
                          <span>{t.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 整體滿意度評分 */}
                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                      播放器使用體驗評分
                    </label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="text-2xl transition hover:scale-125 focus:outline-none"
                        >
                          {star <= rating ? '⭐' : '☆'}
                        </button>
                      ))}
                      <span className="text-xs text-amber-400 font-semibold ml-2">
                        {rating === 5 && '非常滿意！'}
                        {rating === 4 && '挺不錯的'}
                        {rating === 3 && '一般，有待改進'}
                        {rating === 2 && '遇到問題需改進'}
                        {rating === 1 && '體驗不佳'}
                      </span>
                    </div>
                  </div>

                  {/* 稱呼與聯絡方式 */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-zinc-300 mb-1">
                        您的暱稱 / 稱呼 <span className="text-zinc-500">(選填)</span>
                      </label>
                      <input
                        type="text"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        placeholder="例如：小萱、聽歌愛好者"
                        className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
                        maxLength={20}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-zinc-300 mb-1">
                        聯絡方式 / Email <span className="text-zinc-500">(選填)</span>
                      </label>
                      <input
                        type="text"
                        value={contact}
                        onChange={(e) => setContact(e.target.value)}
                        placeholder="方便後續問題跟進回覆"
                        className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
                        maxLength={50}
                      />
                    </div>
                  </div>

                  {/* 回饋內容 */}
                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1">
                      問題描述或功能建議 <span className="text-rose-400">*</span>
                    </label>
                    <textarea
                      required
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      rows={4}
                      placeholder="請具體說明您遇到的問題、操作情境，或期望新增的功能..."
                      className="w-full bg-zinc-800/80 border border-zinc-700 rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 resize-none leading-relaxed"
                      maxLength={1000}
                    />
                    <div className="flex justify-end text-[10px] text-zinc-500 mt-1">
                      {content.length}/1000 字
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-black font-bold text-sm rounded-xl shadow-lg transition disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {isSubmitting ? (
                        <span>正在送出...</span>
                      ) : (
                        <>
                          <span>🚀</span>
                          <span>送出寶貴回饋</span>
                        </>
                      )}
                    </button>
                  </div>
                </>
              )}
            </form>
          ) : (
            /* 回饋管理與試算表匯出面板 (僅管理員解鎖後可見) */
            <div className="space-y-6">
              {/* 頂部月度控制與匯出區 */}
              <div className="bg-zinc-800/60 border border-zinc-700/80 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="w-full sm:w-auto">
                  <label className="block text-[11px] font-semibold text-zinc-400 mb-1">
                    📅 選擇匯出與檢視月份：
                  </label>
                  <select
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="w-full sm:w-48 bg-zinc-900 border border-zinc-700 text-xs text-white rounded-xl px-3 py-2 outline-none focus:border-amber-400"
                  >
                    <option value="all">🌟 全部月份 (全部共 {feedbackList.length} 則)</option>
                    {availableMonths.map((m) => {
                      const count = feedbackList.filter((fb) => fb.monthKey === m).length;
                      return (
                        <option key={m} value={m}>
                          {m} ({count} 則回饋)
                        </option>
                      );
                    })}
                  </select>
                </div>

                {/* 試算表匯出按鈕 */}
                <div className="w-full sm:w-auto flex items-center gap-2">
                  <button
                    onClick={handleExportSpreadsheet}
                    disabled={filteredFeedbacks.length === 0}
                    className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
                    title="匯出為 Excel / Google Sheets 相容之 CSV 試算表 (UTF-8 BOM 繁體中文無亂碼)"
                  >
                    <span>📊</span>
                    <span>匯出該月試算表 (.csv / Excel)</span>
                  </button>

                  {feedbackList.length > 0 && (
                    <button
                      onClick={handleClearAll}
                      className="px-2.5 py-2.5 bg-zinc-800 hover:bg-red-900/40 text-zinc-400 hover:text-red-300 border border-zinc-700 rounded-xl text-xs transition"
                      title="清空所有回饋記錄"
                    >
                      🗑️
                    </button>
                  )}
                </div>
              </div>

              {/* 統計指標卡片 */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-zinc-950/50 border border-zinc-800 p-3 rounded-xl text-center">
                  <span className="text-[10px] text-zinc-400 block mb-0.5">
                    {selectedMonth === 'all' ? '全部月份' : `${selectedMonth} 月`} 回饋筆數
                  </span>
                  <span className="text-xl font-black text-amber-400">{stats.total} 則</span>
                </div>
                <div className="bg-zinc-950/50 border border-zinc-800 p-3 rounded-xl text-center">
                  <span className="text-[10px] text-zinc-400 block mb-0.5">平均用戶滿意度</span>
                  <span className="text-xl font-black text-amber-400">{stats.avgRating} ⭐</span>
                </div>
              </div>

              {/* 管理員進階設定折疊面板 (密碼修改與雲端同步) */}
              <div className="bg-zinc-950/40 border border-zinc-800 rounded-2xl p-4 space-y-3">
                <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <span>⚙️</span>
                  <span>管理員專屬設定</span>
                </div>

                {/* 修改管理員密碼 */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pt-1 border-t border-zinc-800/80">
                  <div>
                    <span className="text-xs text-zinc-300 font-medium">後台解鎖密碼</span>
                    <p className="text-[10px] text-zinc-500">當前密碼預設為 0903，建議設定為您自己的專屬密碼</p>
                  </div>
                  {isChangingPasscode ? (
                    <div className="flex items-center gap-1.5 w-full sm:w-auto">
                      <input
                        type="text"
                        value={newPasscode}
                        onChange={(e) => setNewPasscode(e.target.value)}
                        placeholder="新密碼..."
                        className="bg-zinc-800 border border-zinc-700 rounded-lg px-2.5 py-1 text-xs text-white w-28 outline-none focus:border-amber-400"
                      />
                      <button
                        onClick={handleChangePasscode}
                        className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold rounded-lg transition"
                      >
                        儲存
                      </button>
                      <button
                        onClick={() => setIsChangingPasscode(false)}
                        className="px-2 py-1 text-zinc-400 hover:text-white text-xs"
                      >
                        取消
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setIsChangingPasscode(true)}
                      className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 text-xs rounded-lg transition"
                    >
                      修改密碼
                    </button>
                  )}
                </div>

                {/* 跨用戶雲端同步設定 (Google Sheets / Webhook) */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pt-2 border-t border-zinc-800/80">
                  <div>
                    <span className="text-xs text-zinc-300 font-medium">跨設備 Google 試算表即時同步 (選填)</span>
                    <p className="text-[10px] text-zinc-500">
                      填入 Google Apps Script 或 Webhook 網址，其他使用者在不同電腦提交時，將自動即時同步進您的 Google Sheets！
                    </p>
                  </div>
                  {isEditingWebhook ? (
                    <div className="flex items-center gap-1.5 w-full sm:w-auto">
                      <input
                        type="url"
                        value={tempWebhook}
                        onChange={(e) => setTempWebhook(e.target.value)}
                        placeholder="https://script.google.com/..."
                        className="bg-zinc-800 border border-zinc-700 rounded-lg px-2.5 py-1 text-xs text-white w-48 outline-none focus:border-amber-400"
                      />
                      <button
                        onClick={handleSaveWebhook}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition"
                      >
                        儲存
                      </button>
                      <button
                        onClick={() => setIsEditingWebhook(false)}
                        className="px-2 py-1 text-zinc-400 hover:text-white text-xs"
                      >
                        取消
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setTempWebhook(webhookUrl);
                        setIsEditingWebhook(true);
                      }}
                      className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 text-xs rounded-lg transition"
                    >
                      {webhookUrl ? '已綁定 (點擊修改)' : '設定 Google 試算表 Webhook'}
                    </button>
                  )}
                </div>
              </div>

              {/* 回饋清單項目展示 */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="text-xs font-bold text-zinc-300 tracking-wider flex items-center gap-1.5">
                    <span>📋 回饋詳細記錄</span>
                    <span className="text-[11px] text-amber-400 font-mono">({filteredFeedbacks.length} 則)</span>
                  </h4>

                  {filteredFeedbacks.length > 0 && (
                    <div className="flex items-center gap-1 bg-zinc-950/80 border border-zinc-800 p-1 rounded-xl self-start sm:self-auto">
                      <button
                        type="button"
                        onClick={() => setViewMode('table')}
                        className={`px-3 py-1 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                          viewMode === 'table'
                            ? 'bg-amber-500 text-zinc-950 font-bold shadow-sm'
                            : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                        title="表格檢視 (欄位依內容自動調整大小)"
                      >
                        <span>📊</span>
                        <span>表格模式 (自適應欄寬)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setViewMode('card')}
                        className={`px-3 py-1 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                          viewMode === 'card'
                            ? 'bg-amber-500 text-zinc-950 font-bold shadow-sm'
                            : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                        title="卡片列表檢視"
                      >
                        <span>🗂️</span>
                        <span>卡片模式</span>
                      </button>
                    </div>
                  )}
                </div>

                {loading ? (
                  <div className="text-center py-8 text-zinc-500 text-xs">載入中...</div>
                ) : filteredFeedbacks.length === 0 ? (
                  <div className="text-center py-10 border border-dashed border-zinc-800 rounded-2xl text-zinc-500 text-xs space-y-1">
                    <p className="text-2xl">📭</p>
                    <p>該月份目前沒有回饋記錄</p>
                    <p className="text-[10px] text-zinc-600">歡迎點擊上方「填寫回饋問題」留下您的第一筆建議！</p>
                  </div>
                ) : viewMode === 'table' ? (
                  /* 📊 自適應表格模式 (欄位依內容自動調整大小) */
                  <div className="overflow-x-auto rounded-2xl border border-zinc-800 bg-zinc-950/50 max-h-[350px] overflow-y-auto">
                    <table className="w-full text-left text-xs border-collapse table-auto">
                      <thead className="sticky top-0 z-10">
                        <tr className="border-b border-zinc-800 bg-zinc-900/95 backdrop-blur-md text-zinc-400 font-semibold text-[11px]">
                          <th className="py-2.5 px-3.5 whitespace-nowrap">時間</th>
                          <th className="py-2.5 px-3 whitespace-nowrap">類型</th>
                          <th className="py-2.5 px-3 whitespace-nowrap">評分</th>
                          <th className="py-2.5 px-3 whitespace-nowrap">用戶 / 聯絡</th>
                          <th className="py-2.5 px-3.5 min-w-[200px] w-auto">回饋問題內容 (自動展開)</th>
                          <th className="py-2.5 px-3 whitespace-nowrap">瀏覽器與裝置 (重點)</th>
                          <th className="py-2.5 px-2 text-center whitespace-nowrap">操作</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-800/60">
                        {filteredFeedbacks.map((item) => {
                          const parsed = parseDeviceInfo(item.deviceInfo);
                          return (
                            <tr key={item.id} className="hover:bg-zinc-800/30 transition">
                              {/* 時間 */}
                              <td className="py-3 px-3.5 whitespace-nowrap font-mono text-[11px] text-zinc-400 align-top">
                                <div>{new Date(item.createdAt).toLocaleDateString('zh-TW')}</div>
                                <div className="text-[10px] text-zinc-500">
                                  {new Date(item.createdAt).toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' })}
                                </div>
                              </td>

                              {/* 類型 */}
                              <td className="py-3 px-3 whitespace-nowrap align-top">
                                <span className="inline-block px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-md font-semibold text-[10px]">
                                  {item.typeName}
                                </span>
                              </td>

                              {/* 滿意度 */}
                              <td className="py-3 px-3 whitespace-nowrap align-top">
                                <span className="text-amber-400 font-medium" title={`${item.rating} 顆星`}>
                                  {'⭐'.repeat(item.rating)}
                                </span>
                              </td>

                              {/* 稱呼與聯絡 */}
                              <td className="py-3 px-3 whitespace-nowrap align-top">
                                <div className="font-bold text-zinc-200">{item.userName}</div>
                                {item.contact ? (
                                  <div className="text-[10px] text-zinc-400 max-w-[130px] truncate" title={item.contact}>
                                    {item.contact}
                                  </div>
                                ) : (
                                  <span className="text-[10px] text-zinc-600">無聯絡資訊</span>
                                )}
                              </td>

                              {/* 回饋內容 (自適應欄位大小，自動換行) */}
                              <td className="py-3 px-3.5 text-zinc-200 align-top leading-relaxed whitespace-pre-wrap break-words min-w-[200px]">
                                {item.content}
                              </td>

                              {/* 瀏覽器與裝置環境 (重點展示) */}
                              <td className="py-3 px-3 whitespace-nowrap align-top">
                                <div
                                  className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-zinc-900 border border-zinc-800 rounded-lg text-[11px] text-zinc-300 shadow-sm"
                                  title={`完整環境代碼：\n${item.deviceInfo || '無'}`}
                                >
                                  <span>{parsed.deviceIcon}</span>
                                  <span className="font-semibold text-amber-300">{parsed.os}</span>
                                  <span className="text-zinc-600">•</span>
                                  <span className="text-zinc-200">{parsed.browser}</span>
                                  <span className="text-[9px] text-zinc-400 bg-zinc-800 px-1 py-0.2 rounded font-mono">
                                    {parsed.deviceLabel}
                                  </span>
                                </div>
                              </td>

                              {/* 操作 (刪除) */}
                              <td className="py-3 px-2 text-center whitespace-nowrap align-top">
                                <button
                                  onClick={() => handleDeleteItem(item.id)}
                                  className="text-zinc-500 hover:text-red-400 transition p-1 hover:bg-red-500/10 rounded text-xs"
                                  title="刪除此筆記錄"
                                >
                                  ✕
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  /* 🗂️ 卡片模式 */
                  <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
                    {filteredFeedbacks.map((item) => {
                      const parsed = parseDeviceInfo(item.deviceInfo);
                      return (
                        <div
                          key={item.id}
                          className="p-3.5 bg-zinc-800/40 border border-zinc-700/60 rounded-xl hover:border-zinc-600 transition space-y-2"
                        >
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-md font-semibold text-[10px]">
                                {item.typeName}
                              </span>
                              <span className="font-bold text-zinc-200">{item.userName}</span>
                              <span className="text-amber-400 text-xs">
                                {'⭐'.repeat(item.rating)}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] text-zinc-500 font-mono">
                                {new Date(item.createdAt).toLocaleDateString('zh-TW')}
                              </span>
                              <button
                                onClick={() => handleDeleteItem(item.id)}
                                className="text-zinc-500 hover:text-red-400 transition"
                                title="刪除此筆記錄"
                              >
                                ✕
                              </button>
                            </div>
                          </div>

                          <p className="text-xs text-zinc-300 leading-relaxed whitespace-pre-wrap">
                            {item.content}
                          </p>

                          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-zinc-800/80 text-[10px]">
                            {item.contact ? (
                              <div className="text-zinc-500 flex items-center gap-1">
                                <span>聯絡資訊：</span>
                                <span className="text-zinc-300">{item.contact}</span>
                              </div>
                            ) : (
                              <span className="text-zinc-600">無聯絡資訊</span>
                            )}

                            {/* 裝置環境重點標籤 */}
                            <div
                              className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-zinc-900 border border-zinc-800 rounded text-zinc-300 text-[10px]"
                              title={`完整環境代碼：\n${item.deviceInfo}`}
                            >
                              <span>{parsed.deviceIcon}</span>
                              <span className="text-amber-300">{parsed.os}</span>
                              <span className="text-zinc-600">•</span>
                              <span>{parsed.browser}</span>
                              <span className="text-zinc-500 font-mono">({parsed.deviceLabel})</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* 管理員專屬密碼解鎖對話框 */}
        {showPasswordModal && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-20 animate-fade-in">
            <form
              onSubmit={handleVerifyPassword}
              className="bg-zinc-900 border border-zinc-700 p-6 rounded-2xl w-full max-w-sm shadow-2xl text-center space-y-4"
            >
              <div className="text-3xl">🔐</div>
              <div>
                <h3 className="text-sm font-bold text-white">管理員身分驗證</h3>
                <p className="text-[11px] text-zinc-400 mt-1">
                  請輸入管理員密碼以解鎖用戶回饋後台與試算表匯出功能
                </p>
              </div>

              <div>
                <input
                  type="password"
                  value={inputPassword}
                  onChange={(e) => {
                    setInputPassword(e.target.value);
                    setPasswordError('');
                  }}
                  placeholder="請輸入密碼 (預設: 0903)"
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white text-center tracking-widest placeholder-zinc-500 outline-none focus:border-amber-400"
                  autoFocus
                />
                {passwordError && (
                  <p className="text-rose-400 text-[11px] mt-1.5 font-medium">{passwordError}</p>
                )}
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="flex-1 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs rounded-xl transition"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-black font-bold text-xs rounded-xl shadow transition"
                >
                  確認解鎖
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
