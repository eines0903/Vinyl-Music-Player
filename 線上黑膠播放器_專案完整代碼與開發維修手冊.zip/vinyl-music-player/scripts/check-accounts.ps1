try {
    $outlook = New-Object -ComObject Outlook.Application
    $namespace = $outlook.GetNamespace("MAPI")
    $accounts = $namespace.Accounts
    Write-Output "COUNT=$($accounts.Count)"
    foreach ($acc in $accounts) {
        Write-Output "ACCOUNT=$($acc.SmtpAddress)"
    }
} catch {
    Write-Output "OUTLOOK_ERR=$($_.Exception.Message)"
}
