async function runTests() {
  console.log('=== [1] HTTP & Module Delivery Test ===');
  const endpoints = [
    'http://localhost:5173/',
    'http://localhost:5173/src/main.tsx',
    'http://localhost:5173/src/App.tsx',
    'http://localhost:5173/src/components/LyricModal.tsx',
    'http://localhost:5173/src/components/FeedbackModal.tsx',
    'http://localhost:5173/src/utils/feedbackExport.ts',
    'http://localhost:5173/src/components/ButtonSettingsModal.tsx',
    'http://localhost:5173/src/hooks/useButtonSettings.ts',
  ];
  for (const ep of endpoints) {
    const res = await fetch(ep);
    if (res.status === 200) {
      console.log(`[PASS] ${ep} -> 200 OK`);
    } else {
      console.error(`[FAIL] ${ep} -> ${res.status}`);
      process.exit(1);
    }
  }

  console.log('\n=== [2] Online Lyrics API (LRCLIB) Live Test ===');
  const lrcRes = await fetch('https://lrclib.net/api/search?q=Coldplay+Yellow');
  const lrcData = await lrcRes.json();
  const hasSynced = lrcData.some((item) => item.syncedLyrics && item.syncedLyrics.length > 0);
  console.log(`[PASS] LRCLIB query returned ${lrcData.length} candidate(s), syncedLyrics found: ${hasSynced}`);

  console.log('\n=== [3] YouTube ID Extraction Test ===');
  const testUrls = [
    'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
    'https://youtu.be/kJQP7kiw5Fk',
    'https://www.youtube.com/embed/kJQP7kiw5Fk',
  ];
  const ytRegex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?/\s]{11})/;
  for (const u of testUrls) {
    const match = u.match(ytRegex);
    const id = match ? match[1] : null;
    const isOk = id === 'kJQP7kiw5Fk';
    console.log(`[${isOk ? 'PASS' : 'FAIL'}] Extracted from ${u}: ${id}`);
    if (!isOk) process.exit(1);
  }

  console.log('\n=== [4] Clean Query Utility Test ===');
  const sample = "WOODZ - 파랗게 (Love Me Harder) [Official MV]_128k";
  const cleaned = sample
    .replace(/\s*[([（【].*?(MV|Official|Audio|Video|Lyrics|Lyric|Full|1080[pP]|4[kK]|Live|HD|HQ).*?[)\]）】]/gi, '')
    .replace(/[-_]?(128[kK]|320[kK]|flac|mp3)/gi, '')
    .trim();
  console.log(`[PASS] Raw: "${sample}" -> Cleaned: "${cleaned}"`);

  console.log('\n🎉 ALL VERIFICATION TESTS PASSED SUCCESSFULLY! 🎉');
}

runTests();
