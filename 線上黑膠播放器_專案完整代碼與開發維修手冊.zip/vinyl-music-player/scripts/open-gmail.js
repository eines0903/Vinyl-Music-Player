import { exec } from 'child_process';

const subject = '【線上黑膠音樂播放器】專案完整代碼、開發與維修改正紀錄手冊 (Designed by 温采穎 & 蔡懷萱)';
const body = `Hi Alina,

這是一起合作打造的【線上黑膠音樂播放器 (Vinyl Music Player v2.0)】完整專案記錄、原始碼與開發手冊！

【📦 附件解壓縮方式】
為了避免 Gmail 安全機制誤阻擋程式碼，附件已加上安全防護附檔名「.zip.txt」：
👉 下載附件後，只需在檔名點右鍵「重新命名」，把最後面的「.txt」刪除，即可正常解壓縮！

【✨ 本次成果亮點】
1. 桌面寵物大小的迷你黑膠播放器 (Mini Player)：
   - 280px 精巧小卡，可滑鼠按住自由拖曳至螢幕任意位置
   - 播放時迷你黑膠平滑旋轉，中央顯示專輯封面
   - 包含音量調整、一鍵靜音、循環模式切換，且完全零廣告干擾
2. 無限自訂命名播放清單：
   - 可建立多組自訂清單（如：深夜沉浸、工作專注）
   - 系統自動產生「最近一個月最愛歌曲 (Monthly Favorites)」
   - 完整計算每首歌的播放次數，並生成個人專屬聆聽報告 (Monthly Wrapped)
3. 歌曲添加順序選單：
   - 支援手動、新增日期 (最新/最舊)、最熱門、發布日期 (最新/最舊)
4. 隱藏歌曲清單 (🔻/🔺 按鈕)：
   - 點擊🔻可收合清單，只留主播放器與旋轉黑膠置中展示
5. 音訊引擎防中斷維修與唯一ID匹配：
   - 徹底修復切歌中斷 (AbortError) 與 A 歌播成 B 歌問題

【📁 專案封包與手冊內容】
- 包含完整專案程式碼與架構檔案
- 內附兩份詳盡手冊：PROJECT_DEVELOPMENT_MANUAL.md 與 USER_MANUAL.md

歡迎一起在 GitHub / VS Code Live Share 共同協作共編！

Designed & Built by 温采穎 & 蔡懷萱
`;

const encodedSubject = encodeURIComponent(subject);
const encodedBody = encodeURIComponent(body);
const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=alina.wen0409@gmail.com&su=${encodedSubject}&body=${encodedBody}`;

exec(`cmd /c start "" "${gmailUrl}"`, (err) => {
  if (err) {
    console.error('啟動失敗:', err);
  } else {
    console.log('✅ 已成功啟動瀏覽器開啟 Gmail 撰寫視窗！');
  }
});
